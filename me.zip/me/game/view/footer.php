</main>
<footer>
    <p>This is the footer.</p>
</footer>
</body>
</html>
